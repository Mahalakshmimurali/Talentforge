package com.ace.job.recruitment.service;

import com.ace.job.recruitment.entity.Reviews;

public interface ReviewService {

	Reviews saveReview(Reviews reviews);

}
