package com.ace.job.recruitment.controller;

import com.ace.job.recruitment.model.Course;
import com.ace.job.recruitment.repository.CourseRepository;
import com.ace.job.recruitment.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping("/admin/courses")
public class CourseController {
    @Autowired
    private CourseService courseService;
    
    @Autowired
    private CourseRepository courseRepository;

    @GetMapping
    public String listCourses(Model model) {
        List<Course> courses = courseService.getAllCourses();
        System.out.println("Retrieved courses: " + courses); // Debugging log
        model.addAttribute("courses", courses);
        return "admin/course-list";
    }

    @GetMapping("/candidate/course-details/{id}")
    public String getCourseDetails(@PathVariable Integer id, Model model) {
        Course course = courseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        model.addAttribute("course", course);
        return "candidate/course-details";
    }
    @GetMapping("/add")
    public String showAddCourseForm(Model model) {
        model.addAttribute("course", new Course());
        return "admin/course-form";
    }

    @PostMapping("/add")
    public String addCourse(@Valid @ModelAttribute("course") Course course, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "admin/course-form";
        }

        System.out.println("Attempting to save course: " + course); // Log course data

        try {
            courseService.saveCourse(course);
            System.out.println("Course saved successfully.");
        } catch (Exception e) {
            e.printStackTrace(); // Log full error
            model.addAttribute("errorMessage", "Error saving course: " + e.getMessage());
            return "admin/course-form";
        }

        return "redirect:/admin/courses";
    }

}
