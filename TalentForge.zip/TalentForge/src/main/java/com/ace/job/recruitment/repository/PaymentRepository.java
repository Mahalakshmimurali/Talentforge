package com.ace.job.recruitment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ace.job.recruitment.model.Payment;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
}
