package com.ace.job.recruitment.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.ace.job.recruitment.entity.Vacancy;
import com.ace.job.recruitment.repository.VacancyRepository;
import com.ace.job.recruitment.service.VacancyService;

@Controller
public class HomePageController {

	@Autowired
	private VacancyService vacancyService;

	@Autowired
	private VacancyRepository vacancyRepository;
	
	@GetMapping("/candidate/home")
    public String home(Model model) {
        // Add any attributes needed for Thymeleaf
        return "candidate/home"; 
    }

	@ModelAttribute("vacancyList")
	public List<Vacancy> getVacancyListByUrgent() {
		List<Vacancy> list = vacancyService.getUrgentVacancy();

		if (list == null || list.isEmpty()) {
			List<Vacancy> allList = vacancyRepository.findAllByActiveTrue();
			list = new ArrayList<>();

			if (allList.size() > 6) {
				list = allList.subList(0, 6);
			} else {
				list.addAll(allList);
			}
		}
		System.out.print("____________" + list.size() + "____________");

		return list;
	}

	@GetMapping("/vacancy_list")
	public String showHomePage(Model model) {
	    List<Vacancy> list = vacancyService.getUrgentVacancy();
	    
	    // Add null check before operations
	    if (list == null) {
	        list = new ArrayList<>();
	    }
	    
	    if (list.size() < 7) {
	        List<Vacancy> nonUrgentList = vacancyRepository.findAllByActiveTrueAndUrgentFalse();
	        
	        if (nonUrgentList != null) {
	            list.addAll(nonUrgentList);
	        }
	    }
	    
	    if (list.isEmpty()) {
	        List<Vacancy> allList = vacancyRepository.findAllByActiveTrue();
	        if (allList != null && !allList.isEmpty()) {
	            list = allList.size() > 6 ? allList.subList(0, 6) : allList;
	        }
	    }

	    if (list != null && !list.isEmpty()) {
	        model.addAttribute("vacancyList", list.subList(0, Math.min(list.size(), 6)));
	    } else {
	        model.addAttribute("vacancyList", new ArrayList<>());
	    }
	    
	    return "candidate/home";
	}
}