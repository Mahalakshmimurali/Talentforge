package com.ace.job.recruitment.service;

import com.ace.job.recruitment.model.Course;
import com.ace.job.recruitment.repository.CourseRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseService {
	@Autowired
	private CourseRepository courseRepository;
	
	public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

	public void saveCourse(Course course) {
	    System.out.println("Saving course: " + course);
	    courseRepository.save(course);
	    System.out.println("Saved course successfully.");
	}
}