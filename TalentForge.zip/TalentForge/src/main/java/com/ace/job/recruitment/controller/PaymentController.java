package com.ace.job.recruitment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ace.job.recruitment.model.Course;
import com.ace.job.recruitment.model.Payment;
import com.ace.job.recruitment.repository.CourseRepository;
import com.ace.job.recruitment.repository.PaymentRepository;

@Controller
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    // Show Payment Page
    @GetMapping("/{courseId}")
    public String showPaymentPage(@PathVariable Integer courseId, Model model) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        model.addAttribute("course", course);
        return "payment";
    }

    // Process Payment
    @PostMapping("/process")
    public String processPayment(
            @RequestParam Integer courseId,
            @RequestParam String paymentMethod,
            @RequestParam(required = false) String cardNumber,
            @RequestParam(required = false) String expiryDate,
            @RequestParam(required = false) String cvv,
            @RequestParam(required = false) String upiId,
            @RequestParam(required = false) String bankName,
            @RequestParam(required = false) String accountNumber) {

        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Payment payment = new Payment();
        payment.setCourse(course);
        payment.setAmount(course.getPrice());
        payment.setPaymentMethod(paymentMethod);

        if ("Card".equals(paymentMethod)) {
            payment.setCardNumber(cardNumber);
        } else if ("UPI".equals(paymentMethod)) {
            payment.setUpiId(upiId);
        } else if ("NetBanking".equals(paymentMethod)) {
            payment.setBankName(bankName);
            payment.setAccountNumber(accountNumber);
        }

        payment.setPaymentStatus("SUCCESS"); // Assume payment success for now
        paymentRepository.save(payment);

        return "redirect:/payment/success";
    }
    // Success Page
    @GetMapping("/success")
    public String paymentSuccess() {
        return "payment-success";
    }
}
