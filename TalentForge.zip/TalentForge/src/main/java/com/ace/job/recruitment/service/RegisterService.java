package com.ace.job.recruitment.service;

import java.util.Optional;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ace.job.recruitment.model.Register;
import com.ace.job.recruitment.repository.RegisterRepository;

@Service
public class RegisterService {
    private final RegisterRepository registerRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JavaMailSender mailSender;

    @Autowired
    public RegisterService(RegisterRepository registerRepository, BCryptPasswordEncoder passwordEncoder, JavaMailSender mailSender) {
        this.registerRepository = registerRepository;
        this.passwordEncoder = passwordEncoder;
        this.mailSender = mailSender;
    }

    /**
     * Register a new candidate.
     */
    public Register registerCandidate(@Valid Register register) {
        if (registerRepository.findByEmail(register.getEmail()).isPresent()) {
            throw new IllegalArgumentException("❌ Email already registered! Please use a different email.");
        }

        if (register.getPassword() == null || register.getPassword().isEmpty()) {
            throw new IllegalArgumentException("❌ Password cannot be null or empty");
        }

        register.setPassword(passwordEncoder.encode(register.getPassword())); // Encrypt password
        Register savedRegister = registerRepository.save(register); // Save to database

        try {
            sendThankYouEmail(savedRegister.getEmail(), savedRegister.getName()); // Send email
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        return savedRegister;
    }

    /**
     * Authenticate login credentials.
     */
    public Optional<Register> loginCandidate(String email, String password) {
        Optional<Register> register = registerRepository.findByEmail(email);
        if (register.isPresent() && passwordEncoder.matches(password, register.get().getPassword())) {
            return register;
        }
        return Optional.empty();
    }

    /**
     * Save candidate details.
     */
    public void save(@Valid Register register) {
        if (registerRepository.findByEmail(register.getEmail()).isPresent()) {
            throw new IllegalArgumentException("❌ Email already registered! Please use a different email.");
        }

        if (register.getPassword() == null || register.getPassword().isEmpty()) {
            throw new IllegalArgumentException("❌ Password cannot be null or empty");
        }

        register.setPassword(passwordEncoder.encode(register.getPassword())); // Encrypt password
        registerRepository.save(register);

        try {
            sendThankYouEmail(register.getEmail(), register.getName()); // Send email
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    /**
     * Send a professional thank-you email with HTML format.
     */
    private void sendThankYouEmail(String email, String name) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(email);
        helper.setSubject("Welcome to TalentForge - Thank You for Registering!");

        String emailContent = "<html>" +
                "<body style='font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; padding: 20px;'>" +
                "<div style='max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);'>" +
                "<img src='cid:logoImage' alt='TalentForge Logo' style='width: 180px; margin-bottom: 10px;'>" +
                "<h2 style='color: #333;'>🎉 Welcome, " + name + "! 🎉</h2>" +
                "<p style='color: #555; font-size: 16px;'>Thank you for registering with <b>TalentForge</b>. 🚀 We are excited to have you on board!</p>" +
                "<p style='color: #555; font-size: 16px;'>Our team will contact you soon to guide you through the next steps. 🎯</p>" +
                "<br>" +

                "<hr style='border: 1px solid #ddd; margin: 20px 0;'>" +
                "<p style='font-size: 14px; color: #777;'>📌 Need Help? Feel free to reach out to us:</p>" +

                "<p style='font-size: 18px; font-weight: bold;'>📧 <a href='mailto:info@talentforge.com' style='text-decoration: none; color: #007bff;'>info@talentforge.com</a></p>" +
                "<p style='font-size: 18px; font-weight: bold;'>🌍 <a href='http://www.talentforge.com' style='text-decoration: none; color: #28a745;'>www.talentforge.com</a></p>" +
                "<p style='font-size: 18px; font-weight: bold;'>📞 +91 63744 63362</p>" +

                "<br>" +
                "<p style='color: #777; font-size: 13px;'>© 2025 TalentForge. All rights reserved.</p>" +
                "</div>" +
                "</body>" +
                "</html>";


        helper.setText(emailContent, true); 
        ClassPathResource resource = new ClassPathResource("static/images/home/logo.png"); 
        helper.addInline("logoImage", resource);

        mailSender.send(message);

}
}
