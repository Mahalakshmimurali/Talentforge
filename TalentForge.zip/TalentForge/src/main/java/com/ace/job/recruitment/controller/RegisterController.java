package com.ace.job.recruitment.controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.ace.job.recruitment.model.Register;
import com.ace.job.recruitment.service.RegisterService;

@Controller
@RequestMapping("/candidate/register")
public class RegisterController {
    private final RegisterService registerService;

    public RegisterController(RegisterService registerService) {
        this.registerService = registerService;
    }

    // Show Registration Form
    @GetMapping("")
    public String showRegisterForm(Model model) {
        model.addAttribute("register", new Register());
        return "candidate/register"; // Ensure this file exists in templates/candidate/
    }

    // Handle Registration
    @PostMapping("/submit")
    public String registerUser(@Valid @ModelAttribute Register register, BindingResult result, Model model) {
        System.out.println("🔹 Inside registerUser method");

        if (result.hasErrors()) {
            System.out.println("❌ Validation Errors Found: " + result.getAllErrors());
            model.addAttribute("register", register);
            return "candidate/register";  // Return to form if errors exist
        }

        try {
            System.out.println("🔹 Saving user: " + register);
            registerService.save(register);
            System.out.println("✅ User saved successfully!");
            return "redirect:/candidate/register/success";  // Redirect to success page
        } catch (Exception e) {
            System.out.println("❌ Error during registration: " + e.getMessage());
            model.addAttribute("error", "Registration failed. Try again.");
            return "candidate/register";  // Return with error message
        }
    }

    // Success Page Mapping
    @GetMapping("/success")
    public String registrationSuccess() {
        return "candidate/success"; // Ensure this file exists in templates/candidate/
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "candidate/login"; // Corrected path
    }

    // Process Login
    @PostMapping("/login")
    public String loginCandidate(@RequestParam String email, 
                                 @RequestParam String password, 
                                 HttpSession session, 
                                 Model model) {
        Optional<Register> register = registerService.loginCandidate(email, password);
        
        if (register.isPresent()) {
            session.setAttribute("loggedInUser", register.get()); // Store user in session
            return "redirect:/candidate/profile"; // Redirect to profile page
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "candidate/login"; // Show login page again with error
        }
    }


    @GetMapping("/home")
    public String showHomePage() {
        return "candidate/home"; // Ensure this file exists
    }
    
}
