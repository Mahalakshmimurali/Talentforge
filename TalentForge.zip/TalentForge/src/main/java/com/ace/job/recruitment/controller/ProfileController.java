package com.ace.job.recruitment.controller;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.support.SessionStatus;
import com.ace.job.recruitment.model.Register;

@Controller
public class ProfileController {

    @GetMapping("/candidate/profile")
    public String showProfile(HttpSession session, Model model) {
        Register register = (Register) session.getAttribute("loggedInUser");

        // Debugging logs
        System.out.println("Session User: " + register);

        if (register == null) {
            System.out.println("Session is null, redirecting to login...");
            return "redirect:/candidate/register/login"; // Ensure correct login URL
        }
        

        model.addAttribute("register", register);
        return "candidate/profile"; 
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, SessionStatus sessionStatus) {
        System.out.println("Logging out...");
        session.invalidate(); 
        sessionStatus.setComplete();
        return "redirect:/candidate/register/login";
    }
}
